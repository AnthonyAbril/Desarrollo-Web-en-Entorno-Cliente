/*
Crear una variable con la cadena “Centro de Estudios IES el Grao”. Encontrar la posición de 
la palabra “Estudios” dentro de la cadena. Encontrar la última posición del carácter “a” 
dentro de la cadena.
*/

var cadena = "Centro  de  Estudios  IES  el  Grao";

console.log(cadena.indexOf("Estudios"));

console.log(cadena.lastIndexOf("a"));