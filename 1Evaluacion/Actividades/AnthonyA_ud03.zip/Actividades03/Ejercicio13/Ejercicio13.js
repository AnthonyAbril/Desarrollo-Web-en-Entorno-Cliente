/*
Introducir un valor con decimales y redondear al entero superior
*/

var valor = Math.ceil(1.2);

document.writeln(valor);