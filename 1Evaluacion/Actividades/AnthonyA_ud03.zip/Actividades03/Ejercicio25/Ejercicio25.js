/*
Crear una variable con la cadena “Centro  de  Estudios  IES  el  Grao”. Encontrar la cadena 
“Estudios” y devolver la subcadena hasta el final de la cadena. Encontrar el carácter “d” y 
devolver la subcadena hasta el final de la cadena.
*/

var cadena = "Centro  de  Estudios  IES  el  Grao";

console.log(cadena.substring(cadena.indexOf("Estudios")));

console.log(cadena.substring(cadena.indexOf("d")));

