/*
Crear una variable con el contenido “Centro de Estudios Superior” y sustituir “Superior” por 
“IES el Grao”. 
*/

var cadena = "Centro de Estudios Superior”";


console.log(cadena.replace("Superior", "IES el Grao"));