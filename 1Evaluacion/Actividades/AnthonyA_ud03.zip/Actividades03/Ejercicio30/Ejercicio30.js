/*
Crear una Cadena con vuestro nombre completo e indicar cuantas palabras contiene. Por 
ejemplo: Pedro Ros Molina ----> 3 palabras // Jose Luis Martín Gómez -----> 4 palabras.
*/

var cadena = "Pedro Ros Molina";


document.writeln(cadena.split(" ").length+" palabras.");