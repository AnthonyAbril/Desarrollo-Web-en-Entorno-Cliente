/*
Crear una variable con el contenido “Centro de Estudios IES el Grao” y devolver la cadena 
Inversa
*/

var cadena = "Centro de Estudios IES el Grao";

document.writeln(cadena.split().reverse().join());

document.writeln(cadena.split("").reverse().join(""));