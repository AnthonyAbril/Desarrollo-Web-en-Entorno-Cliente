/*
Introducir un valor con decimales y redondear al entero inferior 
*/

var valor = Math.floor(1.2);

document.writeln(valor);