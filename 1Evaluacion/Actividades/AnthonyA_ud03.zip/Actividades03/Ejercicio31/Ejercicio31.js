/*
Crear dos variables. Una variable tendrá como contenido “esto es una prueba de texto” y la 
segunda “LUIS ROS CASTRO”. Convertir la primera variable a mayúscula y en la segunda 
variable a minúsculas.
*/

var cadena1 = "esto es una prueba de texto";
var cadena2 = "LUIS ROS CASTRO";

document.writeln(cadena1.toUpperCase());
document.writeln(cadena2.toLowerCase())