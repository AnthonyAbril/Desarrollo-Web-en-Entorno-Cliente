/*
Introducir un número por el teclado y mostrarlo con tres decimales.
*/

var numeros1 = parseFloat(prompt("Introduce un numero"));

document.writeln(numeros1.toFixed(3));