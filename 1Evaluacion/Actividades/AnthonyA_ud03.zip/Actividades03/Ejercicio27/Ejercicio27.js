/*
Crear una variable con la cadena “Centro de Estudios IES el Grao”. Extraer de la cadena a 
partir de la posición “de” y devolver 11 caracteres. 
*/

var cadena = "Centro de Estudios IES el Grao";

console.log(cadena.substring(cadena.indexOf("de"),cadena.indexOf("de")+11));